import java.io.FileNotFoundException;

public interface Review {


    public void viewCourse()throws FileNotFoundException;


}
