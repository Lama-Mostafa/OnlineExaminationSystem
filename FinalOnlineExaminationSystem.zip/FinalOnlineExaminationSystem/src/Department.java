public enum Department {
    IS,
    CS,
    SE,
    AI
}
