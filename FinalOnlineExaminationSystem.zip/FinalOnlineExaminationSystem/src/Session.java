public enum Session {
    FROM_9_TO_11,
    FROM_11_TO_1,
    FROM_1_TO_3
}
