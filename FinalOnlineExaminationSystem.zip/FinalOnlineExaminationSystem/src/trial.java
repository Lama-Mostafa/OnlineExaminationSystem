//import java.io.File;
//import java.util.Scanner;
//
//public class trial {
//
//    //import javax.swing.undo.AbstractUndoableEdit;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] a)throws FileNotFoundException{
//        Scanner in = new Scanner(System.in);
//        System.out.println("Enter 1 to enter as an Admin\nEnter 2 to enter as an Instructor\nEnter 3 to enter as a Student");
//        File file;
//        Scanner infile;
//        String username;
//        String pass;
//        String name, mobileNumber, emailAddress, name1;
//        int age, count=0,qCount,flag=0;
//        int x = in.nextInt();
//        switch (x) {
//            case 1:
//                file = new File("admin.txt");
//                infile = new Scanner(file);
//                username = in.next();
//                pass = in.next();
//                while (infile.hasNext()) {
//                    count++;
//                    String u = infile.next();
//                    String p = infile.next();
//                    if (u.equals(username) && p.equals(pass)) {
//                        System.out.println("Welcome to Admin panel");
//                        //Read data from file
//                        //method -> while loop to get data about the user
//                        Admin a1;
//                        while (true) {
//                            System.out.println("Press 1 to add Student\nPress 2 to add Instructor\nPress 3 to add Course\nPress 4 to assign Course to a Student\nPress 5 to assign Grade of a Course to a Student\nPress 6 to assign Instructor to a Course\n");
//                            System.out.println("To logout enter -1");
//                            x = in.nextInt();
//                            if (x == -1) {
//                                break;
//                            }
//                            double credit;
//                            switch (x) {
//                                case 1:
//                                    System.out.println("Enter Student name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Student age");
//                                    age = in.nextInt();
//                                    System.out.println("Enter Student mobile number");
//                                    mobileNumber = in.nextLine();
//                                    System.out.println("Enter Student e-mail address");
//                                    emailAddress = in.nextLine();
//                                    a1.createStudent(name, age, mobileNumber, emailAddress);
//                                    break;
//                                case 2:
//                                    System.out.println("Enter Instructor name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Student age");
//                                    age = in.nextInt();
//                                    System.out.println("Enter Student mobile number");
//                                    mobileNumber = in.nextLine();
//                                    System.out.println("Enter Student e-mail address");
//                                    emailAddress = in.nextLine();
//                                    a1.createInstructor(name, age, mobileNumber, emailAddress);
//                                    break;
//                                case 3:
//                                    System.out.println("Enter Course name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Course number of final questions");
//                                    qCount = in.nextInt();
//                                    System.out.println("Enter Course credit hours");
//                                    credit = in.nextInt();
//                                    a1.createCourse(name, qCount, credit);
//                                    break;
//                                case 4:
//                                    System.out.println("Enter Course name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Student name");
//                                    name1 = in.nextLine();
//                                    a1.assignCourseToStudent(name, name1);
//                                    break;
//                                case 5:
//                                    System.out.println("Enter Course name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Student name");
//                                    name1 = in.nextLine();
//                                    System.out.println("Enter grade");
//                                    char c = in.next().charAt(0);
//                                    a1.assignCourseGradetoStudent(name, name1, c);
//                                    break;
//                                case 6:
//                                    System.out.println("Enter Course name");
//                                    name = in.nextLine();
//                                    System.out.println("Enter Instructor name");
//                                    name1 = in.nextLine();
//                                    a1.assignCoursetoInstructor(name, name1);
//                                    break;
//                                case 7:
//
//                                    //default:
//                            }
//                        }
//                        break;
//                    }
//                }
//            case 2:
//                file = new File("instructor.txt");
//                infile = new Scanner(file);
//                username = in.next();
//                pass = in.next();
//                while (infile.hasNext()) {
//                    count++;
//                    String u = infile.next();
//                    String p = infile.next();
//                    if (u.equals(username) && p.equals(pass)) {
//                        flag=1;
//                        for(int i=0;i<count;i++){
//
//                        }
//
//
//                    }
//                }
//                if(flag==0){
//
//                }
//        }
//
//    }
//}
//
//
//
//
//
//
//
//
//
//
//}
